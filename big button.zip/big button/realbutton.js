function showhide() {
    console.log("showhide works");
    let definitionButton = document.getElementById("addDefinition");
    console.log("definitionButton =", definitionButton);
    definitionButton.style.display = "none";
}


/* Line 1. Use of naming the function showhide, which is paired to the HTML
Line 2. A Test To Show Showhide Works
Line 3. Naming a variable the actual part of the html document that it means
Line 4. Another test to check the 

*/

function turnOff(element) {
    element.innerText = "logout";
}